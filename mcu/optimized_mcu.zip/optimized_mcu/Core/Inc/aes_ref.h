#ifndef INC_AES_REF_H_
#define INC_AES_REF_H_

void AES128_encrypt(unsigned char* block, const unsigned char* key);

#endif // INC_AES_REF_H_
